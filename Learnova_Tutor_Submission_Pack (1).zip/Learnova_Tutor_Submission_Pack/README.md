# Learnova Tutor
AI-powered interactive learning assistant.

**Stack:** React + TypeScript + Vite; Node.js + Express + TypeScript; PostgreSQL.  
**Intended hosting:** Netlify frontend + Render backend.

## Project idea
Learnova Tutor aims to support structured lessons, AI-assisted explanations, practice, revision, and interview preparation. Intended learning flow: **WATCH → PAUSE → ASK → UNDERSTAND → PRACTICE → REVISE → PREPARE → INTERVIEW**.

A distinctive design idea is timestamp-aware tutoring: the tutor should use lesson transcript content only up to the learner's current timestamp, along with permitted learning resources. Verify this feature is implemented before claiming it is complete.

## Folders
- `frontend/` — React/TypeScript/Vite UI
- `backend/` — Express/TypeScript API
- `database/migrations/` — PostgreSQL migrations
- `.env.example` — environment-variable names, not real secrets

## Local setup
Prerequisites: Node.js, npm, PostgreSQL.

1. In `backend/`, run `npm install`.
2. Create `backend/.env` using the environment variable names expected by the code. Set `DATABASE_URL`, a unique `JWT_SECRET` (at least 32 characters), `FRONTEND_URL`, and any required AI-provider settings. Never commit `.env`.
3. Create a PostgreSQL database and apply the SQL files in `database/migrations/` in numerical order (the known project has migrations `001` through `005`).
4. Start the backend using the development script defined in `backend/package.json` (commonly `npm run dev`).
5. In `frontend/`, run `npm install`; set `VITE_API_URL=http://localhost:5000/api` in `frontend/.env`.
6. Start the frontend using the script in `frontend/package.json` (commonly `npm run dev`).

Confirm actual package scripts and ports before submitting these instructions.

## Documentation
- [Architecture](docs/ARCHITECTURE.md)
- [API](docs/API.md)
- [Deployment](docs/DEPLOYMENT.md)
- [Testing](docs/TESTING.md)
- [Demo video script](docs/DEMO_VIDEO_SCRIPT.md)
- [Submission checklist](docs/SUBMISSION_CHECKLIST.md)

## Verification note
The frontend production build was previously reported successful and the Render API was reported live. However, a deployed login request later returned HTTP 500. Re-test login, registration, and key features before claiming the deployed app is fully working.
